create
    definer = root@localhost function totalCost(maDonHang int) returns int reads sql data
begin
	declare total int;
    select sum(quantityOrdered*priceEach) into total from orderdetails where orderNumber = maDonHang group by orderNumber;
    return total;
end;

