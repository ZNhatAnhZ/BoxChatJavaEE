create definer = root@localhost trigger before_insert_orderdetails
    before insert
    on orderdetails
    for each row
begin
	declare quantitystock int;
    select quantityInStock into quantitystock from products where productCode = new.productCode;
    if (new.quantityOrdered > quantitystock) then
    signal sqlstate '02000' set message_text = 'Không đủ hàng đáp ứng yêu cầu';
    end if;
end;

