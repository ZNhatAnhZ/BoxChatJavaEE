create definer = root@localhost trigger before_insert_orders
    before insert
    on orders
    for each row
begin
    if (new.requiredDate < current_date() ) then
    signal sqlstate '02000' set message_text = 'Ngày giao hàng không hợp lệ';
    end if;
end;

